package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class homecontroller
{
	@RequestMapping("/")
	public String gothome()
	{
		return "index";
	}
	
  @RequestMapping("/login")
  public String login(Model model)
  {
	  model.addAttribute("userClickedlogin",true );
	  return "login";
  }
  @RequestMapping("/register")
  public String register(Model model)
  {
	  model.addAttribute("userClickedregister",true);
	  return "register";
  }
  
  @RequestMapping("/validate")
	public String validate(@RequestParam(name="userID") String id,
			@RequestParam(name="password") String pwd,
			Model model)
	{
		//validate-hit the database to validate
		//niit
	if(id.equals("niit") && pwd.equals("niit"))
	{
		model.addAttribute("successmessage","you successfull logged in");
	}
	else
	{
		model.addAttribute("successmessage", "invalid details...please try again");
	}
	//sap
	return "index";
  
	
	}
  }




